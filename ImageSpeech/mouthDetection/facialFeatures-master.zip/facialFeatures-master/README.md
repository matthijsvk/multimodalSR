facialFeatures
==============

An OpenCV Python script to extract various features such as left eye, right eye, eyepair, nose, and mouth from frontal face images
