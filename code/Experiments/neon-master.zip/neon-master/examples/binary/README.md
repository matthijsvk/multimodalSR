## Model

This is an implementation of a Binarized Neural Network trained on the MNIST dataset.

### Instructions
```
python binary/train.py -e 20
```
## Citation
```
Binarized Neural Networks: Training Neural Networks with Weights and Activations Constrained to +1 or -1
http://arxiv.org/pdf/1602.02830v3.pdf
```

